#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 24 22:00:37 2020
画直方图
@author: hou
"""

from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
img=np.array(Image.open('junheng.jpg').convert('L'))

plt.figure("lena")
arr=img.flatten()
n, bins, patches = plt.hist(arr, bins=256,facecolor='green', alpha=0.75)  
plt.show()